"""
Example registered automation for GHOST-1's `run_automation` command.

Drop new scripts in this folder named `<name>.py` and GHOST-1's Command agent
can trigger them by name (still gated behind user confirmation in the
orchestrator). Keep automations single-purpose and side-effect-obvious.
"""
from pathlib import Path

def main():
    downloads = Path.home() / "Downloads"
    print(f"[example automation] Would organize files in: {downloads}")
    # Real logic goes here, e.g. sorting files into subfolders by extension.

if __name__ == "__main__":
    main()
