"""
GHOST-1 Waveform Widget
-----------------------
Renders a real-time-looking audio spectrum. Feed it real amplitude data via
`push_levels()` when wired to an actual mic/playback stream; absent that, it
idles on a gentle synthetic animation so the HUD never looks dead.
"""
from __future__ import annotations

import math
import random

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QPainter, QColor, QLinearGradient
from PySide6.QtWidgets import QWidget

from ui.themes import Palette

BAR_COUNT = 32


class WaveformWidget(QWidget):
    def __init__(self, palette: Palette, parent=None):
        super().__init__(parent)
        self.palette = palette
        self.setMinimumHeight(60)
        self._levels = [0.05] * BAR_COUNT
        self._targets = [0.05] * BAR_COUNT
        self._phase = 0.0
        self._active = False

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(33)  # ~30 FPS is plenty for a bar visualizer

    def set_active(self, active: bool) -> None:
        """Call with True while GHOST-1 is speaking/listening, False when idle."""
        self._active = active

    def push_levels(self, levels: list[float]) -> None:
        """Feed real FFT/amplitude data (0.0-1.0), length BAR_COUNT."""
        n = min(len(levels), BAR_COUNT)
        self._targets[:n] = [max(0.03, min(1.0, v)) for v in levels[:n]]

    def _tick(self) -> None:
        self._phase += 0.15
        if not self._active:
            # idle: gentle synthetic breathing pattern
            for i in range(BAR_COUNT):
                self._targets[i] = 0.08 + 0.05 * abs(math.sin(self._phase + i * 0.4))
        else:
            # if nobody pushed real data recently, jitter randomly so it still looks alive
            for i in range(BAR_COUNT):
                self._targets[i] = max(0.05, min(1.0, self._targets[i] + random.uniform(-0.15, 0.15)))

        for i in range(BAR_COUNT):
            self._levels[i] += (self._targets[i] - self._levels[i]) * 0.35

        self.update()

    def paintEvent(self, _event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        w, h = self.width(), self.height()
        bar_width = w / BAR_COUNT
        accent = QColor(self.palette.accent)

        for i, level in enumerate(self._levels):
            bar_h = level * h
            x = i * bar_width
            gradient = QLinearGradient(0, h - bar_h, 0, h)
            top_color = QColor(accent)
            top_color.setAlpha(230)
            bottom_color = QColor(accent)
            bottom_color.setAlpha(60)
            gradient.setColorAt(0.0, top_color)
            gradient.setColorAt(1.0, bottom_color)
            painter.setBrush(gradient)
            painter.setPen(Qt.NoPen)
            painter.drawRoundedRect(
                int(x + bar_width * 0.15), int(h - bar_h),
                int(bar_width * 0.7), int(bar_h), 3, 3,
            )

        painter.end()
