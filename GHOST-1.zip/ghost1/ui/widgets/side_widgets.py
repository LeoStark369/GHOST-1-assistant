"""
GHOST-1 Side Widgets
---------------------
Smaller HUD panels grouped in one module to keep the widget package tidy:
  ClockWidget         - live clock + date.
  WeatherWidget       - current conditions via OpenWeatherMap (optional key).
  NotificationCenter  - floating, auto-dismissing toast notifications.
  CommandHistoryPanel - scrolling log of recent user <-> GHOST-1 turns.
"""
from __future__ import annotations

import logging
from datetime import datetime

import requests
from PySide6.QtCore import Qt, QTimer, QPropertyAnimation, QPoint
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QListWidget, QListWidgetItem, QGraphicsOpacityEffect,
)

from config import settings
from ui.themes import Palette

logger = logging.getLogger("GHOST-1.ui.side_widgets")


class ClockWidget(QWidget):
    def __init__(self, palette: Palette, parent=None):
        super().__init__(parent)
        self.setObjectName("GlassPanel")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 14, 16, 14)

        self.time_label = QLabel("--:--:--")
        self.time_label.setStyleSheet(f"color:{palette.accent}; font-size:28px; font-weight:300;")
        self.date_label = QLabel("")
        self.date_label.setStyleSheet(f"color:{palette.text_secondary}; font-size:11px; letter-spacing:1px;")

        layout.addWidget(self.time_label)
        layout.addWidget(self.date_label)

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._refresh)
        self._timer.start(1000)
        self._refresh()

    def _refresh(self) -> None:
        now = datetime.now()
        self.time_label.setText(now.strftime("%H:%M:%S"))
        self.date_label.setText(now.strftime("%A, %d %B %Y").upper())


class WeatherWidget(QWidget):
    def __init__(self, palette: Palette, lat: float = 9.03, lon: float = 38.74, parent=None):
        # Defaults to Addis Ababa; pass real coordinates in from the app if known.
        super().__init__(parent)
        self.setObjectName("GlassPanel")
        self.lat, self.lon = lat, lon

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 14, 16, 14)
        title = QLabel("WEATHER")
        title.setObjectName("SectionTitle")
        self.condition_label = QLabel("Loading...")
        self.condition_label.setStyleSheet(f"color:{palette.accent}; font-size:16px;")
        self.detail_label = QLabel("")
        self.detail_label.setStyleSheet(f"color:{palette.text_secondary}; font-size:11px;")

        layout.addWidget(title)
        layout.addWidget(self.condition_label)
        layout.addWidget(self.detail_label)

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._refresh)
        self._timer.start(10 * 60 * 1000)  # refresh every 10 minutes
        self._refresh()

    def _refresh(self) -> None:
        if not settings.openweather_key:
            self.condition_label.setText("No API key")
            self.detail_label.setText("Set OPENWEATHER_API_KEY in .env")
            return
        try:
            resp = requests.get(
                "https://api.openweathermap.org/data/2.5/weather",
                params={
                    "lat": self.lat, "lon": self.lon,
                    "appid": settings.openweather_key, "units": "metric",
                },
                timeout=6,
            )
            resp.raise_for_status()
            data = resp.json()
            temp = data["main"]["temp"]
            desc = data["weather"][0]["description"].title()
            self.condition_label.setText(f"{temp:.0f}°C — {desc}")
            self.detail_label.setText(f"Feels like {data['main']['feels_like']:.0f}°C")
        except Exception:
            logger.exception("Weather fetch failed")
            self.condition_label.setText("Unavailable")
            self.detail_label.setText("Could not reach weather service")


class NotificationCenter(QWidget):
    """Stacks transient toast messages; each fades out after a few seconds."""

    def __init__(self, palette: Palette, parent=None):
        super().__init__(parent)
        self.palette = palette
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.layout_ = QVBoxLayout(self)
        self.layout_.setAlignment(Qt.AlignTop | Qt.AlignRight)
        self.layout_.setContentsMargins(0, 0, 0, 0)
        self.layout_.setSpacing(8)

    def notify(self, message: str, kind: str = "info", duration_ms: int = 4000) -> None:
        color = {
            "info": self.palette.accent,
            "success": self.palette.success,
            "error": self.palette.danger,
        }.get(kind, self.palette.accent)

        toast = QLabel(message, self)
        toast.setWordWrap(True)
        toast.setStyleSheet(
            f"""
            background-color: rgba(5, 15, 20, 0.85);
            border: 1px solid {color};
            border-radius: 8px;
            color: {color};
            padding: 10px 14px;
            font-size: 12px;
            """
        )
        toast.setMaximumWidth(280)
        self.layout_.addWidget(toast)

        effect = QGraphicsOpacityEffect(toast)
        toast.setGraphicsEffect(effect)
        fade_in = QPropertyAnimation(effect, b"opacity", toast)
        fade_in.setDuration(250)
        fade_in.setStartValue(0.0)
        fade_in.setEndValue(1.0)
        fade_in.start()
        # keep a reference so it isn't garbage-collected mid-animation
        toast._fade_in_anim = fade_in  # type: ignore[attr-defined]

        QTimer.singleShot(duration_ms, lambda: self._dismiss(toast, effect))

    def _dismiss(self, toast: QLabel, effect: QGraphicsOpacityEffect) -> None:
        fade_out = QPropertyAnimation(effect, b"opacity", toast)
        fade_out.setDuration(300)
        fade_out.setStartValue(1.0)
        fade_out.setEndValue(0.0)
        fade_out.finished.connect(toast.deleteLater)
        fade_out.start()
        toast._fade_out_anim = fade_out  # type: ignore[attr-defined]


class CommandHistoryPanel(QWidget):
    def __init__(self, palette: Palette, parent=None):
        super().__init__(parent)
        self.setObjectName("GlassPanel")
        self.palette = palette
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 14, 16, 14)

        title = QLabel("COMMAND LOG")
        title.setObjectName("SectionTitle")
        layout.addWidget(title)

        self.list_widget = QListWidget()
        self.list_widget.setStyleSheet(
            f"""
            QListWidget {{ background: transparent; border: none; }}
            QListWidget::item {{ padding: 4px 0px; color: {palette.text_secondary}; }}
            """
        )
        layout.addWidget(self.list_widget)

    def add_entry(self, role: str, text: str) -> None:
        prefix = "› YOU" if role == "user" else "‹ GHOST-1"
        color = self.palette.text_secondary if role == "user" else self.palette.accent
        item = QListWidgetItem(f"{prefix}: {text}")
        item.setForeground(_qcolor(color))
        self.list_widget.addItem(item)
        self.list_widget.scrollToBottom()
        # cap history length so the widget doesn't grow unbounded in long sessions
        while self.list_widget.count() > 200:
            self.list_widget.takeItem(0)


def _qcolor(hex_or_rgba: str):
    from PySide6.QtGui import QColor
    return QColor(hex_or_rgba)
