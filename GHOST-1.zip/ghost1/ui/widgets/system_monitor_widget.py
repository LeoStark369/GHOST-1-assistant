"""
GHOST-1 System Monitor Widget
-----------------------------
Glass panel showing live CPU / RAM / GPU / network stats as slim animated
progress bars, polled from system.monitor.SystemMonitor on a 1s QTimer.
"""
from __future__ import annotations

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QColor
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QProgressBar, QHBoxLayout

from system.monitor import SystemMonitor
from ui.themes import Palette


def _styled_bar(palette: Palette) -> QProgressBar:
    bar = QProgressBar()
    bar.setRange(0, 100)
    bar.setTextVisible(False)
    bar.setFixedHeight(6)
    bar.setStyleSheet(
        f"""
        QProgressBar {{
            background-color: rgba(255,255,255,0.06);
            border-radius: 3px;
        }}
        QProgressBar::chunk {{
            background-color: {palette.accent};
            border-radius: 3px;
        }}
        """
    )
    return bar


class _Metric(QWidget):
    def __init__(self, label: str, palette: Palette):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)

        row = QHBoxLayout()
        self.name_label = QLabel(label)
        self.name_label.setStyleSheet(f"color:{palette.text_secondary}; font-size:10px; letter-spacing:1px;")
        self.value_label = QLabel("--")
        self.value_label.setStyleSheet(f"color:{palette.accent}; font-size:11px; font-weight:600;")
        row.addWidget(self.name_label)
        row.addStretch()
        row.addWidget(self.value_label)

        self.bar = _styled_bar(palette)
        layout.addLayout(row)
        layout.addWidget(self.bar)

    def update_value(self, percent: float, text: str) -> None:
        self.bar.setValue(int(max(0, min(100, percent))))
        self.value_label.setText(text)


class SystemMonitorWidget(QWidget):
    def __init__(self, palette: Palette, parent=None):
        super().__init__(parent)
        self.setObjectName("GlassPanel")
        self._monitor = SystemMonitor()

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(10)

        title = QLabel("SYSTEM STATUS")
        title.setObjectName("SectionTitle")
        layout.addWidget(title)

        self.cpu_metric = _Metric("CPU", palette)
        self.ram_metric = _Metric("MEMORY", palette)
        self.gpu_metric = _Metric("GPU", palette)
        self.net_metric = _Metric("NETWORK", palette)
        for m in (self.cpu_metric, self.ram_metric, self.gpu_metric, self.net_metric):
            layout.addWidget(m)

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._refresh)
        self._timer.start(1000)
        self._refresh()

    def _refresh(self) -> None:
        snap = self._monitor.snapshot()
        self.cpu_metric.update_value(snap.cpu_percent, f"{snap.cpu_percent:.0f}%")
        self.ram_metric.update_value(
            snap.ram_percent, f"{snap.ram_used_gb:.1f}/{snap.ram_total_gb:.1f} GB"
        )
        if snap.gpu_percent is not None:
            self.gpu_metric.update_value(snap.gpu_percent, f"{snap.gpu_percent:.0f}%")
        else:
            self.gpu_metric.update_value(0, "N/A")
        net_total_kbps = snap.net_sent_kbps + snap.net_recv_kbps
        self.net_metric.update_value(min(net_total_kbps / 10, 100), f"{net_total_kbps:.0f} KB/s")
