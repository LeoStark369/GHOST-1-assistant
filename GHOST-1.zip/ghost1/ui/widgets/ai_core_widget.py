"""
GHOST-1 AI Core Widget
----------------------
The animated circular "core" at the center of the HUD: concentric rotating
rings, a pulsing glow that intensifies while GHOST-1 is speaking/thinking,
drawn entirely with QPainter (no external image assets needed).
"""
from __future__ import annotations

import math

from PySide6.QtCore import Qt, QTimer, QRectF
from PySide6.QtGui import QPainter, QColor, QPen, QRadialGradient, QConicalGradient
from PySide6.QtWidgets import QWidget

from ui.themes import Palette


class AICoreWidget(QWidget):
    IDLE, LISTENING, THINKING, SPEAKING = range(4)

    def __init__(self, palette: Palette, parent=None):
        super().__init__(parent)
        self.palette = palette
        self.setMinimumSize(220, 220)
        self._angle = 0.0
        self._pulse = 0.0
        self._state = self.IDLE

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(16)  # ~60 FPS

    def set_state(self, state: int) -> None:
        self._state = state

    def _tick(self) -> None:
        speed = {self.IDLE: 0.4, self.LISTENING: 1.2, self.THINKING: 2.2, self.SPEAKING: 1.8}[self._state]
        self._angle = (self._angle + speed) % 360
        self._pulse = (self._pulse + 0.03) % (2 * math.pi)
        self.update()

    def paintEvent(self, _event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        w, h = self.width(), self.height()
        cx, cy = w / 2, h / 2
        base_radius = min(w, h) / 2 - 10

        pulse_scale = 1.0 + 0.06 * math.sin(self._pulse) * (1 if self._state != self.IDLE else 0.4)
        accent = QColor(self.palette.accent)

        # Outer glow
        glow = QRadialGradient(cx, cy, base_radius * 1.6)
        glow_color = QColor(accent)
        glow_color.setAlpha(90 if self._state != self.IDLE else 45)
        glow.setColorAt(0.0, glow_color)
        transparent = QColor(accent)
        transparent.setAlpha(0)
        glow.setColorAt(1.0, transparent)
        painter.setBrush(glow)
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(QRectF(cx - base_radius * 1.6, cy - base_radius * 1.6, base_radius * 3.2, base_radius * 3.2))

        # Rotating conical ring
        conical = QConicalGradient(cx, cy, self._angle)
        conical.setColorAt(0.0, QColor(accent))
        faded = QColor(accent)
        faded.setAlpha(0)
        conical.setColorAt(1.0, faded)
        ring_pen = QPen()
        ring_pen.setWidthF(4)
        ring_pen.setBrush(conical)
        painter.setPen(ring_pen)
        painter.setBrush(Qt.NoBrush)
        r1 = base_radius * pulse_scale
        painter.drawEllipse(QRectF(cx - r1, cy - r1, r1 * 2, r1 * 2))

        # Inner counter-rotating ring
        painter.save()
        painter.translate(cx, cy)
        painter.rotate(-self._angle * 1.7)
        painter.translate(-cx, -cy)
        pen2 = QPen(QColor(self.palette.accent_alt))
        pen2.setWidthF(2)
        pen2.setStyle(Qt.DashLine)
        painter.setPen(pen2)
        r2 = base_radius * 0.72
        painter.drawEllipse(QRectF(cx - r2, cy - r2, r2 * 2, r2 * 2))
        painter.restore()

        # Solid core disc
        core_gradient = QRadialGradient(cx, cy, base_radius * 0.5)
        core_gradient.setColorAt(0.0, QColor(self.palette.accent_alt))
        core_center = QColor(self.palette.accent)
        core_center.setAlpha(200)
        core_gradient.setColorAt(1.0, core_center)
        painter.setBrush(core_gradient)
        painter.setPen(Qt.NoPen)
        r3 = base_radius * 0.38 * (0.95 + 0.05 * math.sin(self._pulse * 2))
        painter.drawEllipse(QRectF(cx - r3, cy - r3, r3 * 2, r3 * 2))

        painter.end()
