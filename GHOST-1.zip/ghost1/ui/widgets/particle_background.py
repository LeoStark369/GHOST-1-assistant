"""
GHOST-1 Particle Background
----------------------------
A lightweight drifting-particle field with faint connecting lines between
nearby particles, rendered behind all other HUD panels for depth. Pure
QPainter, no OpenGL required, tuned to stay cheap at 60 FPS with ~80 particles.
"""
from __future__ import annotations

import random
from dataclasses import dataclass

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QPainter, QColor, QPen
from PySide6.QtWidgets import QWidget

from ui.themes import Palette

PARTICLE_COUNT = 80
LINK_DISTANCE = 110


@dataclass
class Particle:
    x: float
    y: float
    vx: float
    vy: float
    radius: float


class ParticleBackground(QWidget):
    def __init__(self, palette: Palette, parent=None):
        super().__init__(parent)
        self.palette = palette
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        self._particles: list[Particle] = []
        self._seeded = False

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(16)

    def _seed(self) -> None:
        w, h = max(self.width(), 1), max(self.height(), 1)
        self._particles = [
            Particle(
                x=random.uniform(0, w),
                y=random.uniform(0, h),
                vx=random.uniform(-0.15, 0.15),
                vy=random.uniform(-0.15, 0.15),
                radius=random.uniform(1.0, 2.6),
            )
            for _ in range(PARTICLE_COUNT)
        ]
        self._seeded = True

    def resizeEvent(self, event) -> None:
        self._seed()
        super().resizeEvent(event)

    def _tick(self) -> None:
        if not self._seeded:
            self._seed()
        w, h = self.width(), self.height()
        for p in self._particles:
            p.x += p.vx
            p.y += p.vy
            if p.x < 0 or p.x > w:
                p.vx *= -1
            if p.y < 0 or p.y > h:
                p.vy *= -1
        self.update()

    def paintEvent(self, _event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        accent = QColor(self.palette.accent)

        # links first, so dots draw on top
        link_pen = QPen(accent)
        for i, p1 in enumerate(self._particles):
            for p2 in self._particles[i + 1:]:
                dx, dy = p1.x - p2.x, p1.y - p2.y
                dist = (dx * dx + dy * dy) ** 0.5
                if dist < LINK_DISTANCE:
                    alpha = int(60 * (1 - dist / LINK_DISTANCE))
                    if alpha <= 0:
                        continue
                    link_pen.setColor(QColor(accent.red(), accent.green(), accent.blue(), alpha))
                    painter.setPen(link_pen)
                    painter.drawLine(int(p1.x), int(p1.y), int(p2.x), int(p2.y))

        painter.setPen(Qt.NoPen)
        dot_color = QColor(accent)
        dot_color.setAlpha(160)
        painter.setBrush(dot_color)
        for p in self._particles:
            painter.drawEllipse(int(p.x - p.radius), int(p.y - p.radius), int(p.radius * 2), int(p.radius * 2))

        painter.end()
