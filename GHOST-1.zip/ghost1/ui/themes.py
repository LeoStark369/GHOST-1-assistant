"""
GHOST-1 Themes
--------------
Two futuristic themes (dark / light), each exposing a palette dict (used
directly by custom-painted widgets) and a Qt stylesheet (used by standard
widgets: buttons, text panels, scrollbars).
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Palette:
    bg: str
    panel: str
    panel_border: str
    accent: str
    accent_dim: str
    accent_alt: str
    text_primary: str
    text_secondary: str
    danger: str
    success: str


DARK = Palette(
    bg="#03060a",
    panel="rgba(10, 22, 33, 0.55)",
    panel_border="rgba(0, 224, 255, 0.35)",
    accent="#00e5ff",
    accent_dim="#0a4d5c",
    accent_alt="#7df9ff",
    text_primary="#e8fbff",
    text_secondary="#7fb8c9",
    danger="#ff3860",
    success="#39ffb0",
)

LIGHT = Palette(
    bg="#eef6f9",
    panel="rgba(255, 255, 255, 0.55)",
    panel_border="rgba(0, 140, 186, 0.35)",
    accent="#0089b3",
    accent_dim="#bfe7f2",
    accent_alt="#00b6d9",
    text_primary="#08313f",
    text_secondary="#3d6f7d",
    danger="#d1274a",
    success="#0a9e6c",
)


def get_palette(theme: str) -> Palette:
    return LIGHT if theme == "light" else DARK


def build_stylesheet(p: Palette) -> str:
    return f"""
    QWidget {{
        background-color: transparent;
        color: {p.text_primary};
        font-family: 'Segoe UI', 'Consolas', monospace;
    }}

    QMainWindow {{
        background-color: {p.bg};
    }}

    #GlassPanel {{
        background-color: {p.panel};
        border: 1px solid {p.panel_border};
        border-radius: 14px;
    }}

    QLabel#SectionTitle {{
        color: {p.accent};
        font-size: 12px;
        font-weight: 600;
        letter-spacing: 3px;
        text-transform: uppercase;
    }}

    QTextEdit, QPlainTextEdit {{
        background-color: rgba(0,0,0,0.15);
        border: 1px solid {p.panel_border};
        border-radius: 8px;
        padding: 8px;
        color: {p.text_primary};
        selection-background-color: {p.accent_dim};
    }}

    QLineEdit {{
        background-color: rgba(0,0,0,0.2);
        border: 1px solid {p.accent};
        border-radius: 18px;
        padding: 8px 16px;
        color: {p.text_primary};
    }}

    QPushButton {{
        background-color: rgba(0, 229, 255, 0.08);
        border: 1px solid {p.accent};
        border-radius: 10px;
        padding: 6px 14px;
        color: {p.accent};
        font-weight: 600;
    }}
    QPushButton:hover {{
        background-color: rgba(0, 229, 255, 0.2);
    }}
    QPushButton:pressed {{
        background-color: rgba(0, 229, 255, 0.35);
    }}

    QScrollBar:vertical {{
        background: transparent;
        width: 8px;
    }}
    QScrollBar::handle:vertical {{
        background: {p.accent_dim};
        border-radius: 4px;
    }}
    """
