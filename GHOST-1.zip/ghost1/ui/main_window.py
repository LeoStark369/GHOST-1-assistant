"""
GHOST-1 Main Window
--------------------
Assembles the full holographic HUD: particle background, animated AI core,
waveform, system monitor, clock, weather, notifications, command history,
and the text/voice input bar. Talks to the Orchestrator for all "brains" and
to TTSEngine/SpeechEngine for voice I/O.
"""
from __future__ import annotations

import logging

from PySide6.QtCore import Qt, QObject, Signal
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLineEdit, QPushButton,
    QLabel, QTextEdit, QGridLayout, QSizePolicy,
)

from config import settings
from core.orchestrator import Orchestrator, GhostResponse
from ui.themes import get_palette, build_stylesheet
from ui.widgets.ai_core_widget import AICoreWidget
from ui.widgets.waveform_widget import WaveformWidget
from ui.widgets.particle_background import ParticleBackground
from ui.widgets.system_monitor_widget import SystemMonitorWidget
from ui.widgets.side_widgets import ClockWidget, WeatherWidget, NotificationCenter, CommandHistoryPanel
from voice.tts_engine import TTSEngine
from voice.speech_engine import SpeechEngine

logger = logging.getLogger("GHOST-1.ui")


class _Bridge(QObject):
    """Lets background threads (voice pipeline) safely hand results to the Qt thread."""
    wake_detected = Signal()
    command_heard = Signal(str)


class GhostMainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("GHOST-1 — Global Heuristic Operating System Terminal")
        self.resize(1280, 800)

        self.palette = get_palette(settings.theme)
        self.setStyleSheet(build_stylesheet(self.palette))

        self.orchestrator = Orchestrator()
        self.tts = TTSEngine()
        self.bridge = _Bridge()
        self.bridge.wake_detected.connect(self._on_wake_detected)
        self.bridge.command_heard.connect(self._on_voice_command)

        self._build_ui()
        self._maybe_start_voice()

    # ------------------------------------------------------------------ #
    def _build_ui(self) -> None:
        central = QWidget()
        self.setCentralWidget(central)

        # Background particle field, stacked behind everything else.
        self.particles = ParticleBackground(self.palette, central)
        self.particles.lower()

        root_layout = QGridLayout(central)
        root_layout.setContentsMargins(20, 20, 20, 20)
        root_layout.setSpacing(16)

        # --- Left column: clock, weather, system monitor -------------- #
        left_col = QVBoxLayout()
        self.clock = ClockWidget(self.palette)
        self.weather = WeatherWidget(self.palette)
        self.system_monitor = SystemMonitorWidget(self.palette)
        left_col.addWidget(self.clock)
        left_col.addWidget(self.weather)
        left_col.addWidget(self.system_monitor)
        left_col.addStretch()

        # --- Center column: AI core, waveform, response + input ------- #
        center_col = QVBoxLayout()
        center_col.setAlignment(Qt.AlignHCenter)

        self.ai_core = AICoreWidget(self.palette)
        center_col.addWidget(self.ai_core, alignment=Qt.AlignHCenter)

        self.status_label = QLabel("SYSTEM READY — say “Hello GHOST” or type below")
        self.status_label.setAlignment(Qt.AlignCenter)
        self.status_label.setStyleSheet(f"color:{self.palette.text_secondary}; letter-spacing:1px; font-size:11px;")
        center_col.addWidget(self.status_label)

        self.waveform = WaveformWidget(self.palette)
        center_col.addWidget(self.waveform)

        self.response_view = QTextEdit()
        self.response_view.setReadOnly(True)
        self.response_view.setMinimumHeight(220)
        center_col.addWidget(self.response_view)

        input_row = QHBoxLayout()
        self.input_line = QLineEdit()
        self.input_line.setPlaceholderText("Type a command or question for GHOST-1...")
        self.input_line.returnPressed.connect(self._on_submit_text)
        self.send_button = QPushButton("SEND")
        self.send_button.clicked.connect(self._on_submit_text)
        input_row.addWidget(self.input_line)
        input_row.addWidget(self.send_button)
        center_col.addLayout(input_row)

        # --- Right column: command history ----------------------------- #
        right_col = QVBoxLayout()
        self.history_panel = CommandHistoryPanel(self.palette)
        right_col.addWidget(self.history_panel)

        root_layout.addLayout(left_col, 0, 0, 2, 1)
        root_layout.addLayout(center_col, 0, 1, 2, 2)
        root_layout.addLayout(right_col, 0, 3, 2, 1)
        root_layout.setColumnStretch(0, 2)
        root_layout.setColumnStretch(1, 4)
        root_layout.setColumnStretch(3, 2)

        # Notification overlay sits on top of everything, top-right corner.
        self.notifications = NotificationCenter(self.palette, central)
        self.notifications.setGeometry(self.width() - 320, 10, 300, 400)

        self.notifications.notify("GHOST-1 online.", kind="success")
        if not settings.has_valid_keys():
            self.notifications.notify(
                "No Gemini API key found — add one to .env to enable the AI agents.",
                kind="error", duration_ms=8000,
            )

    def resizeEvent(self, event) -> None:
        self.particles.setGeometry(self.centralWidget().rect())
        self.notifications.setGeometry(self.width() - 320, 40, 300, 400)
        super().resizeEvent(event)

    # ------------------------------------------------------------------ #
    # Voice pipeline wiring
    # ------------------------------------------------------------------ #
    def _maybe_start_voice(self) -> None:
        try:
            self.speech_engine = SpeechEngine(
                on_wake=lambda: self.bridge.wake_detected.emit(),
                on_command=lambda text: self.bridge.command_heard.emit(text),
            )
            self.speech_engine.start()
            self.tts.set_speaking_callback(self._on_speaking_changed)
        except Exception:
            logger.exception("Voice pipeline failed to start (no mic / missing model?)")
            self.notifications.notify(
                "Voice input unavailable (no microphone or model files). Text input still works.",
                kind="error", duration_ms=8000,
            )

    def _on_wake_detected(self) -> None:
        self.ai_core.set_state(AICoreWidget.LISTENING)
        self.waveform.set_active(True)
        self.status_label.setText("LISTENING...")

    def _on_voice_command(self, text: str) -> None:
        self.input_line.setText(text)
        self._process_input(text)

    def _on_speaking_changed(self, speaking: bool) -> None:
        self.ai_core.set_state(AICoreWidget.SPEAKING if speaking else AICoreWidget.IDLE)
        self.waveform.set_active(speaking)

    # ------------------------------------------------------------------ #
    # Text input
    # ------------------------------------------------------------------ #
    def _on_submit_text(self) -> None:
        text = self.input_line.text().strip()
        if not text:
            return
        self.input_line.clear()
        self._process_input(text)

    def _process_input(self, text: str) -> None:
        self.history_panel.add_entry("user", text)
        self.ai_core.set_state(AICoreWidget.THINKING)
        self.status_label.setText("PROCESSING...")

        # NOTE: for a production build, run this on a QThread/worker so the UI
        # never blocks on network latency. Kept synchronous here for clarity.
        response: GhostResponse = self.orchestrator.handle_user_input(text)

        self._render_response(response)

    def _render_response(self, response: GhostResponse) -> None:
        self.response_view.append(f"<b style='color:{self.palette.accent}'>GHOST-1:</b> {response.text}\n")
        self.history_panel.add_entry("ghost", response.text)

        if response.report_sources:
            sources_html = "<br>".join(
                f"[{i+1}] <a href='{s['url']}' style='color:{self.palette.accent_alt}'>{s['title']}</a>"
                for i, s in enumerate(response.report_sources)
            )
            self.response_view.append(f"<i>Sources:</i><br>{sources_html}\n")

        if response.needs_confirmation:
            self.notifications.notify(response.text, kind="info", duration_ms=6000)

        self.status_label.setText("SYSTEM READY — say “Hello GHOST” or type below")
        self.ai_core.set_state(AICoreWidget.IDLE)
        self.tts.speak(response.text)

    def closeEvent(self, event) -> None:
        try:
            self.speech_engine.stop()
        except Exception:
            pass
        self.orchestrator.shutdown()
        super().closeEvent(event)
