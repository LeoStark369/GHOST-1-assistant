"""
GHOST-1 Configuration
----------------------
Loads secrets from a local .env file (never hardcoded, never logged).
All modules should import `settings` from here rather than reading
os.environ directly, so there is a single source of truth.
"""
from __future__ import annotations

import os
import logging
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
logger = logging.getLogger("GHOST-1")


def _mask(key: str | None) -> str:
    """Never print a real API key to logs/UI."""
    if not key:
        return "<missing>"
    return f"{key[:4]}...{key[-4:]}" if len(key) > 8 else "****"


@dataclass
class Settings:
    gemini_core_key: str = field(default_factory=lambda: os.getenv("GEMINI_CORE_KEY") or os.getenv("GEMINI_API_KEY", ""))
    gemini_research_key: str = field(default_factory=lambda: os.getenv("GEMINI_RESEARCH_KEY") or os.getenv("GEMINI_API_KEY", ""))
    gemini_command_key: str = field(default_factory=lambda: os.getenv("GEMINI_COMMAND_KEY") or os.getenv("GEMINI_API_KEY", ""))

    core_model: str = field(default_factory=lambda: os.getenv("GEMINI_CORE_MODEL", "gemini-2.5-pro"))
    research_model: str = field(default_factory=lambda: os.getenv("GEMINI_RESEARCH_MODEL", "gemini-2.5-pro"))
    command_model: str = field(default_factory=lambda: os.getenv("GEMINI_COMMAND_MODEL", "gemini-2.5-flash"))

    openweather_key: str = field(default_factory=lambda: os.getenv("OPENWEATHER_API_KEY", ""))
    wake_word_threshold: float = field(default_factory=lambda: float(os.getenv("WAKE_WORD_THRESHOLD", "0.6")))
    theme: str = field(default_factory=lambda: os.getenv("GHOST_THEME", "dark"))

    data_dir: Path = field(default_factory=lambda: BASE_DIR / "data")
    memory_db_path: Path = field(init=False)

    def __post_init__(self):
        self.data_dir.mkdir(exist_ok=True)
        self.memory_db_path = self.data_dir / "ghost_memory.db"
        if not self.gemini_core_key:
            logger.warning(
                "No GEMINI_API_KEY found. Copy .env.example to .env and add your key "
                "(https://aistudio.google.com/apikey) before running GHOST-1."
            )
        logger.info(
            "Loaded config | core_key=%s research_key=%s command_key=%s theme=%s",
            _mask(self.gemini_core_key), _mask(self.gemini_research_key),
            _mask(self.gemini_command_key), self.theme,
        )

    def has_valid_keys(self) -> bool:
        return bool(self.gemini_core_key)


settings = Settings()
