"""
GHOST-1 Orchestrator
--------------------
The single entry point the UI (or voice pipeline) talks to. It:
  1. Logs the user's turn to memory.
  2. Asks GeminiCore to classify intent (core / research / command).
  3. Dispatches to the right subsystem.
  4. For "command" routes, enforces a confirmation step for anything sensitive
     BEFORE touching the real system.
  5. Logs GHOST-1's response and returns a structured result the UI can render.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from core.gemini_agents import GeminiCore, GeminiResearch, GeminiCommand
from core.memory import MemoryStore
from research.web_research import ResearchEngine
from system.pc_control import PCController

logger = logging.getLogger("GHOST-1.orchestrator")


@dataclass
class GhostResponse:
    route: str
    text: str
    needs_confirmation: bool = False
    pending_action: Optional[dict] = None
    report_sources: list[dict] = field(default_factory=list)


class Orchestrator:
    def __init__(self):
        self.core = GeminiCore()
        self.research_agent = GeminiResearch()
        self.command_agent = GeminiCommand()
        self.memory = MemoryStore()
        self.research_engine = ResearchEngine(self.research_agent)
        self.pc = PCController()
        self._pending_action: Optional[dict] = None

    # ------------------------------------------------------------------ #
    def handle_user_input(self, text: str) -> GhostResponse:
        self.memory.log_turn("user", text)

        # If we're waiting on a yes/no for a sensitive action, handle that first.
        if self._pending_action is not None:
            return self._resolve_pending_confirmation(text)

        intent = self.core.classify_intent(text)
        route = intent.get("route", "core")
        logger.info("Routed %r -> %s (%s)", text, route, intent.get("reason"))

        if route == "research":
            return self._handle_research(text)
        if route == "command":
            return self._handle_command(text)
        return self._handle_core(text)

    # ------------------------------------------------------------------ #
    def _handle_core(self, text: str) -> GhostResponse:
        reply = self.core.ask(text)
        self.memory.log_turn("ghost", reply, route="core")
        return GhostResponse(route="core", text=reply)

    def _handle_research(self, text: str) -> GhostResponse:
        report, sources = self.research_engine.run(text)
        self.memory.log_turn("ghost", report, route="research")
        return GhostResponse(route="research", text=report, report_sources=sources)

    def _handle_command(self, text: str) -> GhostResponse:
        plan = self.command_agent.plan_action(text)
        action = plan.get("action", "unknown")
        summary = plan.get("human_summary", "Unrecognized command.")

        if action == "unknown":
            self.memory.log_turn("ghost", summary, route="command")
            return GhostResponse(route="command", text=summary)

        if plan.get("requires_confirmation", True):
            self._pending_action = plan
            prompt = f"Confirm: {summary} (yes/no)"
            self.memory.log_turn("ghost", prompt, route="command")
            return GhostResponse(route="command", text=prompt, needs_confirmation=True, pending_action=plan)

        result_text = self._execute_action(plan)
        self.memory.log_turn("ghost", result_text, route="command")
        return GhostResponse(route="command", text=result_text)

    def _resolve_pending_confirmation(self, text: str) -> GhostResponse:
        plan = self._pending_action
        self._pending_action = None
        affirmative = text.strip().lower() in {"yes", "y", "confirm", "do it", "go ahead"}
        if not affirmative:
            self.memory.log_command(plan["action"], plan.get("args", {}), confirmed=False, result="cancelled by user")
            reply = "Cancelled. Standing by."
            self.memory.log_turn("ghost", reply, route="command")
            return GhostResponse(route="command", text=reply)

        result_text = self._execute_action(plan)
        self.memory.log_turn("ghost", result_text, route="command")
        return GhostResponse(route="command", text=result_text)

    def _execute_action(self, plan: dict) -> str:
        action = plan.get("action")
        args = plan.get("args", {})
        try:
            result = self.pc.execute(action, args)
            self.memory.log_command(action, args, confirmed=True, result=result)
            return result
        except Exception as exc:  # noqa: BLE001
            logger.exception("Command execution failed: %s", action)
            self.memory.log_command(action, args, confirmed=True, result=f"error: {exc}")
            return f"Execution failed: {exc}"

    def shutdown(self):
        self.memory.close()
