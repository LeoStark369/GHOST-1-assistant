"""
GHOST-1 Multi-Agent Architecture
--------------------------------
Three specialized Gemini-backed agents that collaborate:

  GeminiCore     - conversation, reasoning, planning. The "voice" of GHOST-1.
  GeminiResearch - web research, summarization, structured report generation.
  GeminiCommand  - translates natural language into concrete PC actions,
                   and REQUIRES confirmation before anything destructive/sensitive.

Each agent is a thin, isolated wrapper around google-generativeai so agents
can use different models, different system prompts, and (optionally)
different API keys/billing.
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import Any, Optional

import google.generativeai as genai

from config import settings

logger = logging.getLogger("GHOST-1.agents")


# --------------------------------------------------------------------------- #
# Shared plumbing
# --------------------------------------------------------------------------- #

class GeminiAgent:
    """Base class: configures a model with its own key + system prompt."""

    def __init__(self, name: str, api_key: str, model_name: str, system_prompt: str):
        self.name = name
        self.model_name = model_name
        self._chat = None
        if not api_key:
            logger.error("%s has no API key configured; agent disabled.", name)
            self._model = None
            return

        genai.configure(api_key=api_key)
        self._model = genai.GenerativeModel(
            model_name=model_name,
            system_instruction=system_prompt,
        )

    def start_chat(self, history: Optional[list] = None):
        if not self._model:
            raise RuntimeError(f"{self.name} is not configured (missing API key).")
        self._chat = self._model.start_chat(history=history or [])
        return self._chat

    def _ensure_chat(self):
        if self._chat is None:
            self.start_chat()
        return self._chat

    def ask(self, prompt: str, **generation_kwargs) -> str:
        """Single-turn-in-context ask, keeps running chat history."""
        if not self._model:
            return f"[{self.name} unavailable: no API key configured]"
        chat = self._ensure_chat()
        try:
            response = chat.send_message(prompt, **generation_kwargs)
            return response.text
        except Exception as exc:  # noqa: BLE001 - surface any API error to the UI, don't crash the app
            logger.exception("%s.ask() failed", self.name)
            return f"[{self.name} error: {exc}]"

    def ask_json(self, prompt: str) -> dict[str, Any]:
        """Ask for a strictly-JSON response and parse it defensively."""
        raw = self.ask(
            prompt,
            generation_config=genai.types.GenerationConfig(response_mime_type="application/json"),
        )
        try:
            return json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            cleaned = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
            try:
                return json.loads(cleaned)
            except Exception:
                logger.warning("%s returned non-JSON payload: %.200s", self.name, raw)
                return {"error": "invalid_json", "raw": raw}


# --------------------------------------------------------------------------- #
# GeminiCore — conversation, reasoning, planning
# --------------------------------------------------------------------------- #

CORE_SYSTEM_PROMPT = """You are GHOST-1 (Global Heuristic Operating System Terminal-1),
a highly capable AI operating system assistant with a calm, precise, faintly
futuristic tone (think: an elite mission-control AI, not a chatty assistant).

Responsibilities:
- Hold natural conversation and maintain context across turns.
- Decide when a request needs the Research agent (open-ended factual/web
  questions) or the Command agent (anything touching the user's PC) and say so
  plainly, e.g. "Routing to Research..." — the orchestrator handles the actual dispatch.
- Give concise, confident answers. Avoid filler and avoid over-explaining.
- For scientific/technical domains (aerospace, AI/ML, PyTorch, Python, robotics,
  physics, math, astronomy, research papers) go deeper and more technical by default.
Never fabricate system state (CPU load, open files, etc.) — that data comes from
the system monitor, not from you.
"""


class GeminiCore(GeminiAgent):
    def __init__(self):
        super().__init__(
            name="GeminiCore",
            api_key=settings.gemini_core_key,
            model_name=settings.core_model,
            system_prompt=CORE_SYSTEM_PROMPT,
        )

    def classify_intent(self, user_text: str) -> dict[str, Any]:
        """Cheap routing call: does this need Research, Command, or just Core?"""
        prompt = f"""Classify the user's message into exactly one route.
Respond with ONLY JSON: {{"route": "core"|"research"|"command", "reason": "<short reason>"}}

Message: {user_text!r}

Guidance:
- "research": needs current/external information, web search, a report, citations.
- "command": asks GHOST-1 to DO something on the PC (open/close apps, files, volume,
  wifi, bluetooth, brightness, launch a website, automation).
- "core": everything else (conversation, reasoning, scientific explanation, math)."""
        result = self.ask_json(prompt)
        if result.get("route") not in {"core", "research", "command"}:
            result = {"route": "core", "reason": "fallback"}
        return result


# --------------------------------------------------------------------------- #
# GeminiResearch — web research, summarization, report generation
# --------------------------------------------------------------------------- #

RESEARCH_SYSTEM_PROMPT = """You are the Research subsystem of GHOST-1.
Given a topic plus a set of already-fetched source snippets (title, url, text),
you:
1. Analyze and cross-check the snippets.
2. Write a clear, well-organized, professional summary/report in your own words
   (never copy long verbatim passages from sources).
3. Note where sources disagree or information may be stale.
4. ALWAYS list the sources actually used, with titles and URLs, at the end.
Output should be structured with short headers, suitable for rendering in a
report dashboard.
"""


class GeminiResearch(GeminiAgent):
    def __init__(self):
        super().__init__(
            name="GeminiResearch",
            api_key=settings.gemini_research_key,
            model_name=settings.research_model,
            system_prompt=RESEARCH_SYSTEM_PROMPT,
        )

    def synthesize_report(self, topic: str, sources: list[dict]) -> str:
        """sources: [{"title": str, "url": str, "snippet": str}, ...]"""
        source_block = "\n\n".join(
            f"[{i+1}] {s['title']} ({s['url']})\n{s['snippet']}"
            for i, s in enumerate(sources)
        )
        prompt = (
            f"Topic: {topic}\n\nSources:\n{source_block}\n\n"
            "Produce the professional report described in your system instructions."
        )
        return self.ask(prompt)


# --------------------------------------------------------------------------- #
# GeminiCommand — PC automation & tool execution
# --------------------------------------------------------------------------- #

COMMAND_SYSTEM_PROMPT = """You are the Command subsystem of GHOST-1. You translate
natural-language requests into ONE structured action from the allowed action set.
You NEVER execute anything yourself — you only decide WHAT should happen; a
separate, sandboxed executor performs it after user confirmation for anything
sensitive.

Respond with ONLY JSON in this shape:
{
  "action": "<one of: open_app, close_app, open_file, search_files, set_volume,
             set_brightness, toggle_wifi, toggle_bluetooth, open_url,
             open_folder, run_automation, unknown>",
  "args": { ... action-specific arguments ... },
  "requires_confirmation": true|false,
  "human_summary": "<one sentence describing exactly what will happen>"
}

Mark requires_confirmation = true for: closing apps, deleting/moving files,
toggling wifi/bluetooth, running automations, or anything irreversible.
Mark it false for read-only or trivially reversible actions (opening an app,
opening a URL, adjusting volume/brightness).
If the request doesn't map cleanly to an action, use "unknown" and explain why
in human_summary.
"""


class GeminiCommand(GeminiAgent):
    def __init__(self):
        super().__init__(
            name="GeminiCommand",
            api_key=settings.gemini_command_key,
            model_name=settings.command_model,
            system_prompt=COMMAND_SYSTEM_PROMPT,
        )

    def plan_action(self, user_text: str) -> dict[str, Any]:
        return self.ask_json(f"Request: {user_text!r}")
