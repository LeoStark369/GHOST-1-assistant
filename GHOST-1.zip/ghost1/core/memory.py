"""
GHOST-1 Memory
--------------
Two layers:
  1. SQLite - durable log of every turn (always available, zero extra deps).
  2. FAISS (optional) - semantic vector search over past turns, so GHOST-1 can
     recall relevant context even outside the immediate chat window. If FAISS
     or an embedding backend isn't available, GHOST-1 silently falls back to
     the SQLite recency-based recall only.
"""
from __future__ import annotations

import sqlite3
import time
import logging
from pathlib import Path
from typing import Optional

from config import settings

logger = logging.getLogger("GHOST-1.memory")

try:
    import faiss  # type: ignore
    import numpy as np
    _FAISS_AVAILABLE = True
except ImportError:
    _FAISS_AVAILABLE = False
    logger.info("faiss not installed - semantic memory recall disabled, using recency-based recall only.")


class MemoryStore:
    def __init__(self, db_path: Optional[Path] = None):
        self.db_path = db_path or settings.memory_db_path
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._init_schema()

        self._faiss_index = None
        self._faiss_id_map: list[int] = []
        if _FAISS_AVAILABLE:
            self._faiss_index = faiss.IndexFlatL2(384)  # assumes a 384-dim embedder if wired up later

    def _init_schema(self):
        self._conn.execute(
            """CREATE TABLE IF NOT EXISTS turns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts REAL NOT NULL,
                role TEXT NOT NULL,          -- 'user' | 'ghost'
                route TEXT,                  -- 'core' | 'research' | 'command'
                content TEXT NOT NULL
            )"""
        )
        self._conn.execute(
            """CREATE TABLE IF NOT EXISTS commands (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts REAL NOT NULL,
                action TEXT NOT NULL,
                args TEXT,
                confirmed INTEGER NOT NULL,
                result TEXT
            )"""
        )
        self._conn.commit()

    # ------------------------------------------------------------------ #
    # Conversation log
    # ------------------------------------------------------------------ #
    def log_turn(self, role: str, content: str, route: Optional[str] = None) -> None:
        self._conn.execute(
            "INSERT INTO turns (ts, role, route, content) VALUES (?, ?, ?, ?)",
            (time.time(), role, route, content),
        )
        self._conn.commit()

    def recent_turns(self, limit: int = 20) -> list[sqlite3.Row]:
        self._conn.row_factory = sqlite3.Row
        cur = self._conn.execute(
            "SELECT * FROM turns ORDER BY id DESC LIMIT ?", (limit,)
        )
        rows = cur.fetchall()
        return list(reversed(rows))

    # ------------------------------------------------------------------ #
    # Command audit log (every PC action, confirmed or not, is recorded)
    # ------------------------------------------------------------------ #
    def log_command(self, action: str, args: dict, confirmed: bool, result: str) -> None:
        import json
        self._conn.execute(
            "INSERT INTO commands (ts, action, args, confirmed, result) VALUES (?, ?, ?, ?, ?)",
            (time.time(), action, json.dumps(args), int(confirmed), result),
        )
        self._conn.commit()

    def close(self):
        self._conn.close()
