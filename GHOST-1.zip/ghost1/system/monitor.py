"""
GHOST-1 System Monitor
----------------------
Polls CPU, RAM, GPU (best-effort via GPUtil), and network throughput for the
HUD's system monitor widget. Designed to be cheap enough to poll every 1s
from a QTimer without blocking the UI thread.
"""
from __future__ import annotations

import time
import logging
from dataclasses import dataclass

import psutil

logger = logging.getLogger("GHOST-1.monitor")

try:
    import GPUtil  # type: ignore
    _GPU_AVAILABLE = True
except ImportError:
    _GPU_AVAILABLE = False
    logger.info("GPUtil not installed - GPU widget will show 'N/A'.")


@dataclass
class SystemSnapshot:
    cpu_percent: float
    ram_percent: float
    ram_used_gb: float
    ram_total_gb: float
    gpu_percent: float | None
    gpu_name: str | None
    net_sent_kbps: float
    net_recv_kbps: float


class SystemMonitor:
    def __init__(self):
        self._last_net = psutil.net_io_counters()
        self._last_time = time.time()
        # Prime the CPU percent counter (first call always returns 0.0).
        psutil.cpu_percent(interval=None)

    def snapshot(self) -> SystemSnapshot:
        now = time.time()
        elapsed = max(now - self._last_time, 1e-6)

        cpu = psutil.cpu_percent(interval=None)
        vm = psutil.virtual_memory()

        net = psutil.net_io_counters()
        sent_kbps = (net.bytes_sent - self._last_net.bytes_sent) / 1024 / elapsed
        recv_kbps = (net.bytes_recv - self._last_net.bytes_recv) / 1024 / elapsed
        self._last_net = net
        self._last_time = now

        gpu_percent = gpu_name = None
        if _GPU_AVAILABLE:
            try:
                gpus = GPUtil.getGPUs()
                if gpus:
                    gpu_percent = gpus[0].load * 100
                    gpu_name = gpus[0].name
            except Exception:
                logger.debug("GPUtil query failed", exc_info=True)

        return SystemSnapshot(
            cpu_percent=cpu,
            ram_percent=vm.percent,
            ram_used_gb=vm.used / (1024 ** 3),
            ram_total_gb=vm.total / (1024 ** 3),
            gpu_percent=gpu_percent,
            gpu_name=gpu_name,
            net_sent_kbps=max(sent_kbps, 0.0),
            net_recv_kbps=max(recv_kbps, 0.0),
        )
