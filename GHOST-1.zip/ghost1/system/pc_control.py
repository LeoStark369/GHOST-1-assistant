"""
GHOST-1 PC Control
------------------
Real, executable actions on the host machine. Windows-first (per spec), with
graceful degradation on macOS/Linux where reasonable so the app doesn't crash
during cross-platform development/testing.

Every method here is called ONLY after the orchestrator has already gotten
user confirmation for sensitive actions - this module trusts its caller and
focuses purely on "how do I actually do X on this OS".
"""
from __future__ import annotations

import os
import sys
import subprocess
import webbrowser
import fnmatch
import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger("GHOST-1.pc_control")

IS_WINDOWS = sys.platform.startswith("win")
IS_MAC = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")


class PCController:
    """Dispatches a structured action dict (from GeminiCommand) to a real OS call."""

    def __init__(self, search_roots: list[str] | None = None):
        self.search_roots = search_roots or [str(Path.home())]

    # ------------------------------------------------------------------ #
    def execute(self, action: str, args: dict[str, Any]) -> str:
        handler = getattr(self, f"_do_{action}", None)
        if handler is None:
            return f"Unknown action '{action}'."
        return handler(args)

    # ------------------------------------------------------------------ #
    # Applications
    # ------------------------------------------------------------------ #
    def _do_open_app(self, args: dict) -> str:
        name = args.get("name", "")
        if not name:
            return "No application name given."
        try:
            if IS_WINDOWS:
                os.startfile(name)  # type: ignore[attr-defined]
            elif IS_MAC:
                subprocess.Popen(["open", "-a", name])
            else:
                subprocess.Popen([name])
            return f"Opened {name}."
        except Exception as exc:
            return f"Could not open '{name}': {exc}"

    def _do_close_app(self, args: dict) -> str:
        name = args.get("name", "")
        if not name:
            return "No application name given."
        try:
            if IS_WINDOWS:
                subprocess.run(["taskkill", "/IM", f"{name}.exe", "/F"], check=True, capture_output=True)
            elif IS_MAC:
                subprocess.run(["pkill", "-x", name], check=True)
            else:
                subprocess.run(["pkill", "-f", name], check=True)
            return f"Closed {name}."
        except subprocess.CalledProcessError as exc:
            return f"Could not close '{name}' (is it running?): {exc}"

    # ------------------------------------------------------------------ #
    # Files & folders
    # ------------------------------------------------------------------ #
    def _do_search_files(self, args: dict) -> str:
        pattern = args.get("pattern", "*")
        matches: list[str] = []
        for root in self.search_roots:
            for dirpath, _dirnames, filenames in os.walk(root):
                for filename in fnmatch.filter(filenames, f"*{pattern}*"):
                    matches.append(str(Path(dirpath) / filename))
                    if len(matches) >= 25:
                        break
                if len(matches) >= 25:
                    break
        if not matches:
            return f"No files matching '{pattern}' found."
        return "Found:\n" + "\n".join(matches)

    def _do_open_file(self, args: dict) -> str:
        path = args.get("path", "")
        p = Path(path).expanduser()
        if not p.exists():
            return f"File not found: {path}"
        try:
            if IS_WINDOWS:
                os.startfile(str(p))  # type: ignore[attr-defined]
            elif IS_MAC:
                subprocess.Popen(["open", str(p)])
            else:
                subprocess.Popen(["xdg-open", str(p)])
            return f"Opened {p.name}."
        except Exception as exc:
            return f"Could not open file: {exc}"

    def _do_open_folder(self, args: dict) -> str:
        path = args.get("path", "")
        p = Path(path).expanduser()
        if not p.exists():
            return f"Folder not found: {path}"
        try:
            if IS_WINDOWS:
                subprocess.Popen(["explorer", str(p)])
            elif IS_MAC:
                subprocess.Popen(["open", str(p)])
            else:
                subprocess.Popen(["xdg-open", str(p)])
            return f"Opened folder {p}."
        except Exception as exc:
            return f"Could not open folder: {exc}"

    # ------------------------------------------------------------------ #
    # Websites
    # ------------------------------------------------------------------ #
    def _do_open_url(self, args: dict) -> str:
        url = args.get("url", "")
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        webbrowser.open(url)
        return f"Launched {url}."

    # ------------------------------------------------------------------ #
    # Volume / brightness
    # ------------------------------------------------------------------ #
    def _do_set_volume(self, args: dict) -> str:
        level = int(args.get("level", 50))
        level = max(0, min(100, level))
        try:
            if IS_WINDOWS:
                # Requires: pip install pycaw comtypes
                from ctypes import cast, POINTER
                from comtypes import CLSCTX_ALL
                from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume

                devices = AudioUtilities.GetSpeakers()
                interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
                volume = cast(interface, POINTER(IAudioEndpointVolume))
                volume.SetMasterVolumeLevelScalar(level / 100.0, None)
            elif IS_MAC:
                subprocess.run(["osascript", "-e", f"set volume output volume {level}"], check=True)
            else:
                subprocess.run(["amixer", "-D", "pulse", "sset", "Master", f"{level}%"], check=True)
            return f"Volume set to {level}%."
        except Exception as exc:
            return f"Could not set volume (missing dependency 'pycaw' on Windows?): {exc}"

    def _do_set_brightness(self, args: dict) -> str:
        level = int(args.get("level", 50))
        level = max(0, min(100, level))
        try:
            if IS_WINDOWS:
                # Requires: pip install screen-brightness-control
                import screen_brightness_control as sbc
                sbc.set_brightness(level)
            elif IS_MAC:
                subprocess.run(["brightness", str(level / 100)], check=True)
            else:
                subprocess.run(["brightnessctl", "set", f"{level}%"], check=True)
            return f"Brightness set to {level}%."
        except Exception as exc:
            return f"Could not set brightness (missing dependency 'screen-brightness-control'?): {exc}"

    # ------------------------------------------------------------------ #
    # Wi-Fi / Bluetooth
    # ------------------------------------------------------------------ #
    def _do_toggle_wifi(self, args: dict) -> str:
        turn_on = bool(args.get("on", True))
        try:
            if IS_WINDOWS:
                state = "enabled" if turn_on else "disabled"
                subprocess.run(
                    ["netsh", "interface", "set", "interface", "Wi-Fi", state],
                    check=True, capture_output=True,
                )
            elif IS_MAC:
                subprocess.run(["networksetup", "-setairportpower", "en0", "on" if turn_on else "off"], check=True)
            else:
                subprocess.run(["nmcli", "radio", "wifi", "on" if turn_on else "off"], check=True)
            return f"Wi-Fi {'enabled' if turn_on else 'disabled'}."
        except Exception as exc:
            return f"Could not toggle Wi-Fi (may require admin rights): {exc}"

    def _do_toggle_bluetooth(self, args: dict) -> str:
        turn_on = bool(args.get("on", True))
        try:
            if IS_WINDOWS:
                # Windows has no simple CLI toggle; PowerShell + Devices API is required.
                ps = (
                    "Get-PnpDevice -Class Bluetooth | "
                    f"{'Enable-PnpDevice' if turn_on else 'Disable-PnpDevice'} -Confirm:$false"
                )
                subprocess.run(["powershell", "-Command", ps], check=True, capture_output=True)
            elif IS_MAC:
                subprocess.run(["blueutil", "-p", "1" if turn_on else "0"], check=True)
            else:
                subprocess.run(["bluetoothctl", "power", "on" if turn_on else "off"], check=True)
            return f"Bluetooth {'enabled' if turn_on else 'disabled'}."
        except Exception as exc:
            return f"Could not toggle Bluetooth (may require admin rights / blueutil): {exc}"

    # ------------------------------------------------------------------ #
    # Custom automation
    # ------------------------------------------------------------------ #
    def _do_run_automation(self, args: dict) -> str:
        """
        Runs a named automation script from ./automations/<name>.py.
        Deliberately does NOT eval arbitrary text - only pre-registered,
        reviewed scripts can be triggered this way.
        """
        name = args.get("name", "")
        script_path = Path(__file__).resolve().parent.parent / "automations" / f"{name}.py"
        if not script_path.exists():
            return f"No registered automation named '{name}'."
        try:
            subprocess.run([sys.executable, str(script_path)], check=True)
            return f"Automation '{name}' completed."
        except subprocess.CalledProcessError as exc:
            return f"Automation '{name}' failed: {exc}"
