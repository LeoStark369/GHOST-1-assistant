"""
GHOST-1 Research Engine
-----------------------
Pipeline: search -> fetch & clean -> hand snippets to GeminiResearch for
synthesis + citation. Uses DuckDuckGo's HTML endpoint for search (no API key
required) and BeautifulSoup for lightweight text extraction.

Swap `_search_web` for a paid search API (Bing/Google/SerpAPI) if you need
higher-quality results - the rest of the pipeline is agnostic to the source.
"""
from __future__ import annotations

import logging
from typing import Any

import requests
from bs4 import BeautifulSoup

logger = logging.getLogger("GHOST-1.research")

HEADERS = {"User-Agent": "Mozilla/5.0 (GHOST-1 Research Agent)"}


class ResearchEngine:
    def __init__(self, research_agent, max_sources: int = 5):
        self.research_agent = research_agent
        self.max_sources = max_sources

    def run(self, query: str) -> tuple[str, list[dict[str, Any]]]:
        results = self._search_web(query)
        sources = []
        for r in results[: self.max_sources]:
            snippet = self._fetch_snippet(r["url"]) or r.get("snippet", "")
            sources.append({"title": r["title"], "url": r["url"], "snippet": snippet})

        if not sources:
            return ("I couldn't find reliable sources for that query.", [])

        report = self.research_agent.synthesize_report(query, sources)
        return report, sources

    # ------------------------------------------------------------------ #
    def _search_web(self, query: str) -> list[dict[str, str]]:
        try:
            resp = requests.post(
                "https://html.duckduckgo.com/html/",
                data={"q": query},
                headers=HEADERS,
                timeout=8,
            )
            resp.raise_for_status()
        except requests.RequestException:
            logger.exception("Web search failed")
            return []

        soup = BeautifulSoup(resp.text, "html.parser")
        results = []
        for result in soup.select(".result__body")[:10]:
            link_tag = result.select_one(".result__a")
            snippet_tag = result.select_one(".result__snippet")
            if not link_tag:
                continue
            results.append(
                {
                    "title": link_tag.get_text(strip=True),
                    "url": link_tag.get("href", ""),
                    "snippet": snippet_tag.get_text(strip=True) if snippet_tag else "",
                }
            )
        return results

    def _fetch_snippet(self, url: str, max_chars: int = 1500) -> str:
        try:
            resp = requests.get(url, headers=HEADERS, timeout=6)
            resp.raise_for_status()
        except requests.RequestException:
            return ""
        soup = BeautifulSoup(resp.text, "html.parser")
        for tag in soup(["script", "style", "nav", "footer", "header"]):
            tag.decompose()
        text = " ".join(soup.get_text(separator=" ").split())
        return text[:max_chars]
