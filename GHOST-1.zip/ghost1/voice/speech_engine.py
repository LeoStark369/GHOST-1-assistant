"""
GHOST-1 Speech Engine
---------------------
Always-on listening pipeline:

  1. Continuously records short audio chunks from the mic.
  2. Runs a fast local transcription pass (faster-whisper, "tiny"/"base" model)
     purely to detect the wake phrase "Hello GHOST" - cheap and offline.
  3. Once woken, switches to full-utterance capture (via SpeechRecognition's
     ambient-noise-aware microphone stream) and transcribes the command with
     a larger local Whisper model for accuracy.

Runs entirely in a background thread and emits results through callbacks so
the Qt UI thread is never blocked by audio I/O or model inference.
"""
from __future__ import annotations

import logging
import queue
import threading
from typing import Callable, Optional

import speech_recognition as sr
from faster_whisper import WhisperModel

from config import settings

logger = logging.getLogger("GHOST-1.speech")

WAKE_PHRASE = "hello ghost"


class SpeechEngine:
    def __init__(
        self,
        on_wake: Optional[Callable[[], None]] = None,
        on_command: Optional[Callable[[str], None]] = None,
        wake_model_size: str = "tiny",
        command_model_size: str = "base",
    ):
        self.on_wake = on_wake
        self.on_command = on_command
        self._recognizer = sr.Recognizer()
        self._mic = sr.Microphone()
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None

        # Two model sizes: a tiny/fast one just for wake-word spotting, and a
        # more accurate one for the real command once we know someone's talking.
        self._wake_model = WhisperModel(wake_model_size, device="cpu", compute_type="int8")
        self._command_model = WhisperModel(command_model_size, device="cpu", compute_type="int8")

        with self._mic as source:
            self._recognizer.adjust_for_ambient_noise(source, duration=1.0)

    # ------------------------------------------------------------------ #
    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._listen_loop, daemon=True)
        self._thread.start()
        logger.info("Speech engine started, listening for wake phrase %r", WAKE_PHRASE)

    def stop(self) -> None:
        self._stop_event.set()

    # ------------------------------------------------------------------ #
    def _listen_loop(self) -> None:
        while not self._stop_event.is_set():
            try:
                text = self._capture_and_transcribe(self._wake_model, phrase_time_limit=3)
            except Exception:
                logger.exception("Wake-word capture failed")
                continue

            if text and WAKE_PHRASE in text.lower():
                logger.info("Wake phrase detected.")
                if self.on_wake:
                    self.on_wake()
                self._handle_command()

    def _handle_command(self) -> None:
        try:
            command_text = self._capture_and_transcribe(self._command_model, phrase_time_limit=10)
        except Exception:
            logger.exception("Command capture failed")
            return
        if command_text and self.on_command:
            self.on_command(command_text)

    def _capture_and_transcribe(self, model: WhisperModel, phrase_time_limit: int) -> str:
        with self._mic as source:
            audio = self._recognizer.listen(source, timeout=None, phrase_time_limit=phrase_time_limit)

        wav_bytes = audio.get_wav_data()
        segments, _info = model.transcribe(_wav_bytes_to_array(wav_bytes), language="en")
        return " ".join(seg.text for seg in segments).strip()


def _wav_bytes_to_array(wav_bytes: bytes):
    """Convert SpeechRecognition's WAV bytes into a float32 array faster-whisper accepts."""
    import io
    import wave
    import numpy as np

    with wave.open(io.BytesIO(wav_bytes)) as wf:
        frames = wf.readframes(wf.getnframes())
        audio = np.frombuffer(frames, dtype=np.int16).astype(np.float32) / 32768.0
    return audio
