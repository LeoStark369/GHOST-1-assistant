"""
GHOST-1 Text-to-Speech
----------------------
Wraps edge-tts (free, high-quality neural voices) to synthesize speech and
play it back without blocking the Qt event loop. Runs synthesis+playback in
a background thread; the UI subscribes to on_speaking_changed to drive the
waveform / AI-core animation while GHOST-1 talks.
"""
from __future__ import annotations

import asyncio
import logging
import tempfile
import threading
from pathlib import Path
from typing import Callable, Optional

import edge_tts

logger = logging.getLogger("GHOST-1.tts")

DEFAULT_VOICE = "en-US-GuyNeural"  # calm, neutral male voice fitting a HUD AI; swap freely


class TTSEngine:
    def __init__(self, voice: str = DEFAULT_VOICE):
        self.voice = voice
        self._on_speaking_changed: Optional[Callable[[bool], None]] = None
        self._lock = threading.Lock()

    def set_speaking_callback(self, callback: Callable[[bool], None]) -> None:
        """UI hooks in here to animate the AI core / waveform while speaking."""
        self._on_speaking_changed = callback

    def speak(self, text: str) -> None:
        """Fire-and-forget: synthesize + play in a background thread."""
        thread = threading.Thread(target=self._speak_blocking, args=(text,), daemon=True)
        thread.start()

    def _speak_blocking(self, text: str) -> None:
        with self._lock:  # serialize so overlapping speech doesn't garble
            self._notify(True)
            try:
                mp3_path = asyncio.run(self._synthesize(text))
                self._play(mp3_path)
            except Exception:
                logger.exception("TTS playback failed")
            finally:
                self._notify(False)

    async def _synthesize(self, text: str) -> Path:
        tmp = Path(tempfile.gettempdir()) / f"ghost1_tts_{abs(hash(text)) % 10_000}.mp3"
        communicate = edge_tts.Communicate(text, self.voice)
        await communicate.save(str(tmp))
        return tmp

    def _play(self, path: Path) -> None:
        # Uses the platform's default player via winsound/afplay/mpg123 to avoid
        # pulling in a heavy audio-playback dependency just for this.
        import sys
        import subprocess

        if sys.platform.startswith("win"):
            import winsound  # type: ignore
            # winsound only plays WAV; for MP3 playback on Windows prefer:
            #   pip install playsound   -> playsound(str(path))
            # Left explicit here so it's obvious this needs a real player wired in.
            try:
                from playsound import playsound  # type: ignore
                playsound(str(path))
            except ImportError:
                logger.warning("Install 'playsound' for MP3 playback on Windows: pip install playsound")
        elif sys.platform == "darwin":
            subprocess.run(["afplay", str(path)], check=False)
        else:
            subprocess.run(["mpg123", "-q", str(path)], check=False)

        path.unlink(missing_ok=True)

    def _notify(self, speaking: bool) -> None:
        if self._on_speaking_changed:
            self._on_speaking_changed(speaking)
