"""
GHOST-1 Entry Point
-------------------
Run with:  python main.py

On first run, copy .env.example to .env and add your Gemini API key from
https://aistudio.google.com/apikey before launching for full functionality.
"""
import sys

from PySide6.QtWidgets import QApplication

from config import settings, logger


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("GHOST-1")

    # Import here (after QApplication exists) so widgets can rely on Qt being initialized.
    from ui.main_window import GhostMainWindow

    window = GhostMainWindow()
    window.show()

    logger.info("GHOST-1 online. Theme=%s", settings.theme)
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
